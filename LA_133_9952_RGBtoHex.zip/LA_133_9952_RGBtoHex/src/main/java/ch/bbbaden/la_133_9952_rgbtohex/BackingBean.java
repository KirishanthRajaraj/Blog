/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.la_133_9952_rgbtohex;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

/**
 *
 * @author rajar
 */
@Named(value = "BackingBean")
@ApplicationScoped
public class BackingBean {
    private int rgbblue = 0;
    int rgbred = 0;
    int rgbgreen = 0;

    public BackingBean() {
    }

    public int getRgbblue() {
        return rgbblue;
    }

    public int getRgbred() {
        return rgbred;
    }

    public int getRgbgreen() {
        return rgbgreen;
    }

    public void setRgbblue(int rgbblue) {
        this.rgbblue = rgbblue;
    }

    public void setRgbred(int rgbred) {
        this.rgbred = rgbred;
    }

    public void setRgbgreen(int rgbgreen) {
        this.rgbgreen = rgbgreen;
    }
    
    public String rgbToHex(){
        String hex = String.format("#%02x%02x%02x", rgbred, rgbgreen, rgbblue); 
        return hex;
    }
    
}
