/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch.bbbaden.la_133_9952_rgbtohex;

/**
 *
 * @author rajar
 */
public class RGBController {
    public String weiterleitung(){
        return "index.xhtml";
    }
}
